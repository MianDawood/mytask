<!DOCTYPE html>
<html>
<?php
include('head.php');
?>
<?php
include('db_connect.php');
?>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php
include('header.php');
?>
  <!-- Left side column. contains the logo and sidebar -->
<?php
include('sidebar.php');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      
        <small>advanced tables</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="plo.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="logout.php">logout</a></li>
      </ol>
    </section>
  


    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
             <div class="box">
            <div class="box-header">
              <h3 class="box-title">Team Users</h3>
            </div>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th>first Name</th>
                <th>Last Name</th>
                <th>Team</th>
                

                </tr>
                </thead>
             <tbody
             <?php
//                      $query="SELECT * FROM tbl_team_user
//INNER JOIN tbl_user on tbl_team_user.user_id=tbl_user.user_id 
//INNER JOIN tbl_team on tbl_team_user.team_id=tbl_team.team_id";
					
					$query = "select user_firstname,user_lastname,team_name,tbl_team_user.* from tbl_team_user 
					left join tbl_user on tbl_team_user.user_id=tbl_user.user_id
					left join tbl_team on tbl_team_user.team_id=tbl_team.team_id";
					
                      $run=mysqli_query($con,$query);
					while($row = mysqli_fetch_array($run))
					{
						$team_name[$row['user_id']][] = $row['team_name'];
						$rec[$row['user_id']] = array($row['user_firstname'],$row['user_lastname']);
						
					}
                      ?>
                      
                      
                <?php foreach($rec as $k => $x):
					?>
                
                
                <tr>
                    <td><?php echo $x[0];?></td>
                    <td><?php echo $x[1];?></td>
                    <td><?php echo implode(", ",$team_name[$k]);?></td>
                  
                    <?php endforeach;?>
    

              </tbody>

              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php
include('footer.php');
?>

  <!-- Control Sidebar -->
<?php
include('aside.php');
?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php
include('scripts.php');
?>
</body>
</html>
